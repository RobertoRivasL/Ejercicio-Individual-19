import java.util.*;

public class EjercicioIndividual19 {

   /**
    * @author Bastián Mariangel
    * */

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa una cadena de texto: ");
        String cadena = scanner.nextLine();
        scanner.close();

        // Leer y desplegar la cadena carácter por carácter
        System.out.println("Cadena de texto ingresada:");
        for (int i = 0; i < cadena.length(); i++) {
            char caracter = cadena.charAt(i);
            System.out.print(caracter + " ");
        }
        System.out.println();

        // Crear un arreglo con las letras de la cadena
        char[] arreglo = new char[cadena.length()];
        for (int i = 0; i < cadena.length(); i++) {
            arreglo[i] = cadena.charAt(i);
        }

        // Contar las letras del abecedario
        int[] contador = new int[26];
        for (int i = 0; i < arreglo.length; i++) {
            char caracter = Character.toLowerCase(arreglo[i]);
            if (Character.isLetter(caracter)) {
                int indice = caracter - 'a';
                contador[indice]++;
            }
        }

        // Desplegar las letras del abecedario y sus cantidades
        System.out.println("Cantidad de letras encontradas:");
        for (int i = 0; i < contador.length; i++) {
            char letra = (char) ('a' + i);
            System.out.println(letra + ": " + contador[i]);
        }
    }
}